# invoice data extraction > 2024-02-20 2:03pm
https://universe.roboflow.com/roboflow-5gpbq/invoice-data-extraction

Provided by a Roboflow user
License: CC BY 4.0

